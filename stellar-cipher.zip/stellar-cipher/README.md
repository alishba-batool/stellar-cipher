# Stellar-Cipher

Cosmic Cryptography System — encrypts text with real AES-128, then maps
every ciphertext byte onto a real star from an actual astronomical
catalog (a magnitude-filtered subset of the **HYG database**). The
mapped stars are connected with a Minimum Spanning Tree to form a unique
"constellation" for your message, rendered on an interactive celestial
map alongside genuine background stars.

Because the star chosen for each byte only depends on the AES key, the
byte's position, and its value, decoding independently regenerates the
exact same constellation from just the encoded string + key — nothing
extra needs to be stored.

## Project structure

```
stellar-cipher/
├── backend/
│   ├── app.py                     # Flask entry point (serves API + frontend)
│   ├── config.py                  # all tunable constants
│   ├── requirements.txt
│   ├── encryption/
│   │   ├── encrypt.py             # AES-128-CBC encryption
│   │   └── decrypt.py             # AES-128-CBC decryption
│   ├── stars/
│   │   ├── coordinate_mapper.py   # ciphertext bytes -> real stars
│   │   ├── graph_builder.py       # MST over angular distance
│   │   └── star_generator.py      # loads/caches the HYG catalog
│   ├── data/
│   │   ├── hyg_subset.csv         # real star catalog (included, ready to use)
│   │   └── README.md              # dataset details + how to swap it
│   ├── visualization/
│   │   └── plotter.py             # server-side PNG export (matplotlib)
│   ├── api/
│   │   └── routes.py              # /api/encrypt /api/decrypt /api/noise /api/plot
│   └── utils/
│       └── helpers.py             # key derivation, entropy, JSON envelopes
└── frontend/
    ├── index.html                 # three-panel UI
    ├── css/style.css              # dark cosmic theme, fully responsive
    └── js/script.js               # canvas rendering, API calls, zoom/pan
```

## Running it

You only need Python. The frontend is served by the same Flask app, so
there's one command and one port.

```bash
cd stellar-cipher/backend
pip install -r requirements.txt
python app.py
```

Then open **http://localhost:5000** in your browser.

That's it — the star catalog (`data/hyg_subset.csv`) is already included,
so it works immediately with no extra downloads. See
`backend/data/README.md` if you want to swap in a bigger/custom dataset
later (full instructions and a direct download link are in there).

## How to use it

1. Leave mode on **ENCODE**.
2. Type a message (up to 280 characters).
3. Enter any passphrase as the **Security Key** (min. 4 characters —
   internally it's SHA-256'd down to a 128-bit AES key, so any string
   works).
4. Adjust the **Noise Filter** slider to control how many background
   stars are drawn (lower magnitude = only the brightest stars).
5. Click **ENCRYPT MESSAGE**. The constellation streams in: real AES-128
   ciphertext, mapped onto real sky coordinates, connected by a minimum
   spanning tree.
6. Hover any bright star to see its name, RA/Dec, magnitude, and the
   ciphertext byte it represents. Scroll to zoom, drag to pan.
7. Copy the **encoded transmission** string shown after encrypting.
8. Switch to **DECODE**, paste it back in with the same key, and it
   reconstructs both the original message and the identical
   constellation.
9. Use the ⭳ export button to download the current view as a PNG.


## Notes on the crypto

This project uses real AES-128-CBC (via `pycryptodome`), not a toy
substitution cipher — it's genuinely how you'd encrypt data, minus a
production KDF (it uses a single SHA-256 pass instead of PBKDF2/Argon2,
which is fine for a portfolio/learning project but shouldn't be treated
as production-grade key derivation).

## Tech stack

- **Backend:** Flask, pycryptodome (AES), NumPy + SciPy (MST via
  `scipy.sparse.csgraph.minimum_spanning_tree`), Matplotlib (PNG export)
- **Frontend:** vanilla HTML/CSS/JS, HTML5 Canvas — no build step, no
  frameworks, works everywhere
