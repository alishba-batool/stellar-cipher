"""
api/routes.py
--------------
HTTP surface of Stellar-Cipher.

    POST /api/encrypt   { message, key, noiseCount?, maxMag? } -> constellation
    POST /api/decrypt   { encoded, key, noiseCount?, maxMag? } -> constellation + message
    GET  /api/noise      ?count=&maxMag=                       -> just background stars
    POST /api/plot       { messageStars, mstEdges, backgroundStars } -> PNG image
    GET  /api/health                                            -> liveness check
"""

from flask import Blueprint, request, send_file
import io

from encryption.encrypt import encrypt_message
from encryption.decrypt import decrypt_message
from stars.coordinate_mapper import map_bytes_to_stars
from stars.graph_builder import build_mst
from stars.star_generator import get_background_stars, load_catalog
from visualization.plotter import render_constellation_png
from utils.helpers import derive_key, shannon_entropy, error_response, success_response
from config import (
    MIN_KEY_LENGTH,
    MAX_MESSAGE_LENGTH,
    NOISE_STAR_MIN_COUNT,
    NOISE_STAR_MAX_COUNT,
    NOISE_STAR_DEFAULT_COUNT,
    MESSAGE_STAR_MAX_MAGNITUDE,
)

api_bp = Blueprint("api", __name__, url_prefix="/api")


def _clamp_noise_count(value):
    try:
        value = int(value)
    except (TypeError, ValueError):
        value = NOISE_STAR_DEFAULT_COUNT
    return max(NOISE_STAR_MIN_COUNT, min(NOISE_STAR_MAX_COUNT, value))


def _build_constellation_payload(ciphertext, key, noise_count, max_mag):
    """Shared logic used by both /encrypt and /decrypt."""
    aes_key = derive_key(key)
    mapped = map_bytes_to_stars(ciphertext, aes_key)
    message_stars = [m["star"] for m in mapped]

    edges = build_mst(message_stars)
    background = get_background_stars(noise_count, max_mag=max_mag)

    star_payload = [
        {
            **m["star"],
            "byteHex": m["hex"],
            "position": m["position"],
        }
        for m in mapped
    ]

    return {
        "stars": star_payload,
        "mstEdges": edges,
        "backgroundStars": background,
        "metrics": {
            "entropy": shannon_entropy(ciphertext),
            "stringLength": len(ciphertext),
            "graphEdges": len(edges),
        },
    }


@api_bp.route("/health", methods=["GET"])
def health():
    try:
        catalog = load_catalog()
        return success_response({
            "status": "online",
            "catalogSize": len(catalog),
        })
    except Exception as exc:
        return error_response(str(exc), status=500)


@api_bp.route("/encrypt", methods=["POST"])
def encrypt():
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    key = data.get("key") or ""
    noise_count = _clamp_noise_count(data.get("noiseCount", NOISE_STAR_DEFAULT_COUNT))
    max_mag = data.get("maxMag", MESSAGE_STAR_MAX_MAGNITUDE)

    if not message:
        return error_response("Enter a message to encrypt")
    if len(message) > MAX_MESSAGE_LENGTH:
        return error_response(f"Message must be {MAX_MESSAGE_LENGTH} characters or fewer")
    if len(key) < MIN_KEY_LENGTH:
        return error_response(f"Key must be at least {MIN_KEY_LENGTH} characters")

    try:
        result = encrypt_message(message, key)
        payload = _build_constellation_payload(
            result["ciphertext"], key, noise_count, max_mag
        )
        payload["encoded"] = result["encoded"]
        return success_response(payload)
    except ValueError as exc:
        return error_response(str(exc))
    except Exception as exc:
        return error_response(f"Encryption failed: {exc}", status=500)


@api_bp.route("/decrypt", methods=["POST"])
def decrypt():
    data = request.get_json(silent=True) or {}
    encoded = (data.get("encoded") or "").strip()
    key = data.get("key") or ""
    noise_count = _clamp_noise_count(data.get("noiseCount", NOISE_STAR_DEFAULT_COUNT))
    max_mag = data.get("maxMag", MESSAGE_STAR_MAX_MAGNITUDE)

    if not encoded:
        return error_response("Paste an encoded message to decrypt")
    if len(key) < MIN_KEY_LENGTH:
        return error_response(f"Key must be at least {MIN_KEY_LENGTH} characters")

    try:
        result = decrypt_message(encoded, key)
        payload = _build_constellation_payload(
            result["ciphertext"], key, noise_count, max_mag
        )
        payload["message"] = result["message"]
        return success_response(payload)
    except ValueError as exc:
        return error_response(str(exc))
    except Exception as exc:
        return error_response(f"Decryption failed: {exc}", status=500)


@api_bp.route("/noise", methods=["GET"])
def noise():
    count = _clamp_noise_count(request.args.get("count", NOISE_STAR_DEFAULT_COUNT))
    max_mag = request.args.get("maxMag", type=float)
    try:
        stars = get_background_stars(count, max_mag=max_mag)
        return success_response({"backgroundStars": stars})
    except Exception as exc:
        return error_response(str(exc), status=500)


@api_bp.route("/plot", methods=["POST"])
def plot():
    data = request.get_json(silent=True) or {}
    message_stars = data.get("stars", [])
    mst_edges = data.get("mstEdges", [])
    background_stars = data.get("backgroundStars", [])
    title = data.get("title", "STELLAR-CIPHER")

    try:
        png_bytes = render_constellation_png(
            message_stars, mst_edges, background_stars, title=title
        )
        return send_file(
            io.BytesIO(png_bytes),
            mimetype="image/png",
            as_attachment=True,
            download_name="stellar-cipher-constellation.png",
        )
    except Exception as exc:
        return error_response(f"Could not render image: {exc}", status=500)
