"""
app.py
------
Entry point for Stellar-Cipher.

Run with:
    python app.py

This starts a single Flask server that:
  1. Serves the JSON API under /api/*  (see api/routes.py)
  2. Serves the static frontend (frontend/index.html, style.css, script.js)

So the whole project runs with one command and one port - no separate
frontend dev server needed.
"""

from flask import Flask, send_from_directory
from flask_cors import CORS

from api.routes import api_bp
from config import FRONTEND_DIR, HOST, PORT, DEBUG


def create_app():
    app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")
    CORS(app)  # harmless if frontend and API share an origin; needed if you
               # ever split them (e.g. Vite dev server on another port)

    app.register_blueprint(api_bp)

    @app.route("/")
    def index():
        return send_from_directory(FRONTEND_DIR, "index.html")

    # Fallback: any non-/api path that matches a static file (css/js/img)
    @app.route("/<path:path>")
    def static_files(path):
        return send_from_directory(FRONTEND_DIR, path)

    return app


app = create_app()

if __name__ == "__main__":
    print(f"Stellar-Cipher running at http://localhost:{PORT}")
    app.run(host=HOST, port=PORT, debug=DEBUG)
