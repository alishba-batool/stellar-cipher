"""
config.py
---------
Central configuration for the Stellar-Cipher backend.
Keep every tunable constant here so the rest of the codebase never
hard-codes a magic number.
"""

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------
# Path to the star catalog CSV. See data/README.md for where this comes from
# and how to swap in your own subset of the HYG database.
STAR_CATALOG_PATH = os.path.join(BASE_DIR, "data", "hyg_subset.csv")

# Stars dimmer than this magnitude are dropped when the catalog is first
# loaded (lower magnitude = brighter star). 6.0 is the traditional
# "naked eye" limit, which keeps the catalog fast to load and pleasant
# to render.
MAGNITUDE_LOAD_LIMIT = 6.0

# ---------------------------------------------------------------------------
# Encryption
# ---------------------------------------------------------------------------
AES_KEY_BYTES = 16          # AES-128
AES_BLOCK_BYTES = 16
MIN_KEY_LENGTH = 4          # minimum characters required in the user's key
MAX_MESSAGE_LENGTH = 280    # keep the constellation readable on screen

# ---------------------------------------------------------------------------
# Star mapping / constellation generation
# ---------------------------------------------------------------------------
# Every ciphertext byte is deterministically hashed to one star in the pool
# below. Keeping the pool restricted to reasonably bright stars means the
# generated constellations stay visually crisp.
MESSAGE_STAR_MAX_MAGNITUDE = 6.0

# Background "noise" stars are the decorative starfield behind the
# constellation. The client can request between these bounds via the
# Noise Filter slider.
NOISE_STAR_MIN_COUNT = 80
NOISE_STAR_MAX_COUNT = 600
NOISE_STAR_DEFAULT_COUNT = 350

# ---------------------------------------------------------------------------
# Flask
# ---------------------------------------------------------------------------
HOST = os.environ.get("STELLAR_CIPHER_HOST", "0.0.0.0")
# Most hosting platforms (Render, Railway, Heroku) inject a standard PORT
# env var and expect the app to bind to it. Fall back to STELLAR_CIPHER_PORT
# for local overrides, then 5000 for plain local dev.
PORT = int(os.environ.get("PORT", os.environ.get("STELLAR_CIPHER_PORT", 5000)))
DEBUG = os.environ.get("STELLAR_CIPHER_DEBUG", "0") == "1"

FRONTEND_DIR = os.path.join(os.path.dirname(BASE_DIR), "frontend")
