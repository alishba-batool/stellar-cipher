# Star Catalog Data

## What's already here

`hyg_subset.csv` is included and ready to use out of the box. It is a real
subset of the **HYG Database** (Hipparcos + Yale Bright Star + Gliese
catalogs merged) — genuine star positions, not synthetic/random data —
filtered down to the **5,070 stars with apparent magnitude ≤ 6.0** (the
traditional naked-eye visibility limit). That keeps the file small
(~210 KB) and the constellation renders fast in the browser, while still
giving the "spatial vectorizer" a large, realistic pool of real sky
coordinates to map ciphertext bytes onto.

Columns used by this project:

| column | meaning |
|---|---|
| `id` | row index (regenerated, 0-based) |
| `proper` | common star name, if any (e.g. "Sirius") |
| `ra` | Right Ascension, in **hours** (0–24) |
| `dec` | Declination, in **degrees** (-90 to 90) |
| `mag` | apparent magnitude (lower = brighter) |
| `spect` | spectral type (e.g. "G2V") |
| `con` | 3-letter constellation abbreviation |

## Downloading the full dataset yourself

If you want more stars, fainter stars, or extra columns (distance,
proper motion, etc.), grab the full HYG database directly from its
official open-source repository:

**https://github.com/astronexus/HYG-Database**

Direct CSV (current version at time of writing):

```
https://raw.githubusercontent.com/astronexus/HYG-Database/main/hyg/CURRENT/hygdata_v41.csv
```

It's public domain / CC-licensed and actively maintained. The full file
is roughly 30–40 MB and contains ~120,000 stars.

## Replacing the dataset in this project

1. Download the full CSV from the link above (or any HYG release).
2. Filter/trim it to whatever subset you want. A quick Python snippet:

   ```python
   import pandas as pd

   df = pd.read_csv("hygdata_v41.csv", low_memory=False)

   # drop the Sun (id 0, ra=dec=0 — not a useful sky point)
   df = df[df["proper"] != "Sol"]

   # keep only stars brighter than magnitude 6 (tweak as you like)
   df = df[df["mag"] <= 6.0]

   cols = ["id", "proper", "ra", "dec", "mag", "spect", "con"]
   df = df[cols].reset_index(drop=True)
   df["id"] = range(len(df))

   df.to_csv("hyg_subset.csv", index=False)
   ```

3. Overwrite `backend/data/hyg_subset.csv` with your new file, keeping the
   same column names (`id, proper, ra, dec, mag, spect, con`).
4. Restart the Flask server (`python app.py`). The catalog is loaded once
   into memory at first request, so a restart is required to pick up
   changes — there's nothing else to configure.

If you want to loosen or tighten the magnitude cutoff without touching
the CSV, edit `MAGNITUDE_LOAD_LIMIT` in `backend/config.py`.
