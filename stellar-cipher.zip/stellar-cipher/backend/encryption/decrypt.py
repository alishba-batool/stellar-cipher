"""
encryption/decrypt.py
----------------------
Reverses encrypt.py: takes the base64 "encoded" string produced during
encoding plus the passphrase, and recovers the original plaintext.

Wrong key / tampered payload -> ValueError, which the API layer turns
into a clean "Decryption failed - check your key" response instead of
a stack trace.
"""

import base64

from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

from utils.helpers import derive_key
from config import AES_BLOCK_BYTES


def decrypt_message(encoded: str, key: str):
    """
    Decrypt an `encoded` (base64 iv+ciphertext) string with `key`.

    Returns:
        dict with:
            message (str)      - recovered plaintext
            ciphertext (bytes) - raw ciphertext bytes (for star mapping,
                                  so the decode view reconstructs the
                                  exact same constellation that encoding
                                  produced)
            iv (bytes)
    """
    if not encoded:
        raise ValueError("Nothing to decode")
    if not key:
        raise ValueError("Key cannot be empty")

    try:
        raw = base64.urlsafe_b64decode(encoded.encode("ascii"))
    except Exception:
        raise ValueError("That doesn't look like a valid encoded message")

    if len(raw) < AES_BLOCK_BYTES * 2:
        raise ValueError("Encoded message is too short to be valid")

    iv, ciphertext = raw[:AES_BLOCK_BYTES], raw[AES_BLOCK_BYTES:]
    aes_key = derive_key(key)

    try:
        cipher = AES.new(aes_key, AES.MODE_CBC, iv)
        padded = cipher.decrypt(ciphertext)
        plaintext_bytes = unpad(padded, AES_BLOCK_BYTES)
        message = plaintext_bytes.decode("utf-8")
    except (ValueError, KeyError):
        # Bad key, corrupted payload, or padding mismatch all land here.
        raise ValueError("Decryption failed - check your key and try again")

    return {
        "message": message,
        "ciphertext": ciphertext,
        "iv": iv,
    }
