"""
encryption/encrypt.py
----------------------
Real AES-128-CBC encryption (via pycryptodome), not a toy cipher.

Flow:
    plaintext (str)
        -> UTF-8 bytes, PKCS7 padded
        -> AES-128-CBC with a random IV
        -> iv + ciphertext, base64-encoded  -> this is the "encoded"
           string the user copies/shares, and what gets visualized
           as a constellation.

The raw ciphertext bytes (without the IV) are also returned separately,
because those are the bytes that get mapped one-to-one onto stars.
"""

import base64
import os

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

from utils.helpers import derive_key
from config import AES_BLOCK_BYTES


def encrypt_message(message: str, key: str):
    """
    Encrypt `message` with `key`.

    Returns:
        dict with:
            encoded (str)      - base64(iv + ciphertext), shareable string
            ciphertext (bytes) - raw ciphertext bytes (for star mapping)
            iv (bytes)         - the random IV used
    """
    if not message:
        raise ValueError("Message cannot be empty")
    if not key:
        raise ValueError("Key cannot be empty")

    aes_key = derive_key(key)
    iv = os.urandom(AES_BLOCK_BYTES)

    cipher = AES.new(aes_key, AES.MODE_CBC, iv)
    plaintext_bytes = message.encode("utf-8")
    padded = pad(plaintext_bytes, AES_BLOCK_BYTES)
    ciphertext = cipher.encrypt(padded)

    encoded = base64.urlsafe_b64encode(iv + ciphertext).decode("ascii")

    return {
        "encoded": encoded,
        "ciphertext": ciphertext,
        "iv": iv,
    }
