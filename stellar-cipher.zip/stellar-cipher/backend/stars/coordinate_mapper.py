"""
stars/coordinate_mapper.py
----------------------------
The heart of the "spatial vectorizer": deterministically maps every byte
of a ciphertext onto one real star from the catalog.

Mapping rule (deterministic + reversible without storing anything extra):

    seed   = SHA256(key_bytes || position(4 bytes, big-endian) || byte)
    index  = int(seed[:8]) % len(catalog)
    star   = catalog[index]

Because the mapping only depends on the AES key, the byte's position and
its value, encoding and decoding independently arrive at the exact same
sequence of stars for the exact same ciphertext - nothing about the
star selection itself needs to be transmitted or stored. This is what
lets the decode view redraw an identical constellation to the one shown
at encode time, using only the encoded string + key.
"""

import hashlib

from stars.star_generator import load_catalog


def map_bytes_to_stars(data: bytes, key: bytes):
    """
    Map each byte of `data` (ciphertext) to a star.

    Returns a list of dicts, one per byte, in order:
        {
          "star": <star dict from catalog>,
          "byte": <int 0-255>,
          "hex": "a3",
          "position": <int>
        }
    """
    catalog = load_catalog()
    n = len(catalog)
    if n == 0:
        raise ValueError("Star catalog is empty")

    mapped = []
    for position, byte_val in enumerate(data):
        seed = hashlib.sha256(
            key + position.to_bytes(4, "big") + bytes([byte_val])
        ).digest()
        index = int.from_bytes(seed[:8], "big") % n
        star = catalog[index]
        mapped.append({
            "star": star,
            "byte": byte_val,
            "hex": f"{byte_val:02x}",
            "position": position,
        })
    return mapped
