"""
stars/graph_builder.py
------------------------
Connects the ordered list of "message stars" into a single constellation
by computing a Minimum Spanning Tree (MST) over their angular distances
on the celestial sphere.

Using an MST (rather than just connecting consecutive stars in order)
means the constellation always reads as one coherent, non-crossing-ish
shape, and is a nicer visual/graph-theory hook for a data-science
portfolio project than a simple polyline.
"""

import math

import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import minimum_spanning_tree


def _angular_distance(ra1_h, dec1_deg, ra2_h, dec2_deg):
    """
    Great-circle (angular) distance in degrees between two sky
    coordinates, using the haversine formula. RA is in hours (0-24),
    Dec in degrees (-90..90).
    """
    ra1 = math.radians(ra1_h * 15.0)
    ra2 = math.radians(ra2_h * 15.0)
    dec1 = math.radians(dec1_deg)
    dec2 = math.radians(dec2_deg)

    dra = ra2 - ra1
    ddec = dec2 - dec1

    a = (math.sin(ddec / 2) ** 2
         + math.cos(dec1) * math.cos(dec2) * math.sin(dra / 2) ** 2)
    a = min(1.0, max(0.0, a))
    c = 2 * math.asin(math.sqrt(a))
    return math.degrees(c)


def build_mst(stars):
    """
    `stars` is a list of star dicts (each with 'ra' and 'dec').

    Returns a list of edges: [[i, j, weight_degrees], ...] where i, j
    are indices into `stars`. Singleton input returns an empty edge list.
    """
    n = len(stars)
    if n <= 1:
        return []

    dist = np.zeros((n, n), dtype=float)
    for i in range(n):
        for j in range(i + 1, n):
            d = _angular_distance(
                stars[i]["ra"], stars[i]["dec"],
                stars[j]["ra"], stars[j]["dec"],
            )
            dist[i, j] = d
            dist[j, i] = d

    sparse = csr_matrix(dist)
    tree = minimum_spanning_tree(sparse)
    tree = tree.tocoo()

    edges = []
    for i, j, w in zip(tree.row, tree.col, tree.data):
        edges.append([int(i), int(j), round(float(w), 4)])

    return edges
