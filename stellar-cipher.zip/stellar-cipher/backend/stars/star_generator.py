"""
stars/star_generator.py
------------------------
Loads the real star catalog (a magnitude-filtered subset of the HYG
database, see data/README.md) once and keeps it in memory. Provides:

    load_catalog()          -> full list of star dicts
    get_background_stars()  -> a random sample used purely as decorative
                                "noise" behind the constellation

Real star data is used everywhere in this app - there are no fake/random
coordinates. Even the background noise stars are genuine HYG entries.
"""

import csv
import random
import threading

from config import STAR_CATALOG_PATH, MAGNITUDE_LOAD_LIMIT

_lock = threading.Lock()
_catalog_cache = None


def _row_to_star(row, idx):
    return {
        "id": idx,
        "name": (row.get("proper") or "").strip(),
        "constellation": (row.get("con") or "").strip(),
        "ra": float(row["ra"]),      # hours, 0-24
        "dec": float(row["dec"]),    # degrees, -90..90
        "mag": float(row["mag"]),    # apparent magnitude, lower = brighter
        "spect": (row.get("spect") or "").strip(),
    }


def load_catalog():
    """
    Load and cache the star catalog CSV. Thread-safe, loads once per
    process. Raises FileNotFoundError with a helpful message if the
    dataset hasn't been added yet.
    """
    global _catalog_cache
    if _catalog_cache is not None:
        return _catalog_cache

    with _lock:
        if _catalog_cache is not None:
            return _catalog_cache

        try:
            with open(STAR_CATALOG_PATH, newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                stars = []
                idx = 0
                for row in reader:
                    try:
                        mag = float(row["mag"])
                    except (ValueError, TypeError):
                        continue
                    if mag > MAGNITUDE_LOAD_LIMIT:
                        continue
                    stars.append(_row_to_star(row, idx))
                    idx += 1
        except FileNotFoundError as exc:
            raise FileNotFoundError(
                f"Star catalog not found at '{STAR_CATALOG_PATH}'. "
                "See backend/data/README.md for how to download and "
                "install the dataset."
            ) from exc

        if not stars:
            raise ValueError(
                "Star catalog loaded but contained zero usable rows. "
                "Check that data/hyg_subset.csv has 'ra', 'dec' and "
                "'mag' columns."
            )

        _catalog_cache = stars
        return _catalog_cache


def get_background_stars(count: int, max_mag: float = None):
    """
    Return `count` randomly sampled stars for decorative background
    rendering, optionally filtered to only include stars brighter than
    `max_mag`.
    """
    catalog = load_catalog()
    pool = catalog
    if max_mag is not None:
        pool = [s for s in catalog if s["mag"] <= max_mag]
        if not pool:
            pool = catalog

    count = max(0, min(count, len(pool)))
    sample = random.sample(pool, count)
    return sample
