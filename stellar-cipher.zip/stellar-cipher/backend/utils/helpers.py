"""
utils/helpers.py
-----------------
Small, dependency-light helpers shared across the backend.
"""

import hashlib
import math
from collections import Counter

from flask import jsonify

from config import AES_KEY_BYTES


def derive_key(passphrase: str) -> bytes:
    """
    Turn an arbitrary user-supplied passphrase into a fixed-length AES-128
    key. SHA-256 the passphrase and take the first 16 bytes. This means
    the user never has to worry about picking a "valid" key length -
    any string works.
    """
    if not isinstance(passphrase, str):
        raise ValueError("Key must be a string")
    digest = hashlib.sha256(passphrase.encode("utf-8")).digest()
    return digest[:AES_KEY_BYTES]


def shannon_entropy(data: bytes) -> float:
    """
    Compute the Shannon entropy (in bits/byte) of a byte string.
    Used purely for the 'Stellar Metrics' readout in the telemetry panel -
    it's a nice, real number that visibly changes with the input, which
    is satisfying to watch update as you type.
    """
    if not data:
        return 0.0
    counts = Counter(data)
    length = len(data)
    entropy = 0.0
    for count in counts.values():
        p = count / length
        entropy -= p * math.log2(p)
    return round(entropy, 3)


def error_response(message: str, status: int = 400):
    """Consistent JSON error envelope for the API."""
    return jsonify({"success": False, "error": message}), status


def success_response(payload: dict, status: int = 200):
    payload = dict(payload)
    payload["success"] = True
    return jsonify(payload), status
