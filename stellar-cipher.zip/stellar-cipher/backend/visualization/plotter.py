"""
visualization/plotter.py
--------------------------
Renders a constellation (message stars + MST edges + background noise)
to a PNG image server-side, using matplotlib. This powers the "Export
Image" button - everything else in the UI is drawn live on an HTML5
canvas, but a downloadable static image is handy for sharing.
"""

import io

import matplotlib
matplotlib.use("Agg")  # headless, no display needed
import matplotlib.pyplot as plt


def render_constellation_png(message_stars, mst_edges, background_stars,
                              title="STELLAR-CIPHER"):
    """
    message_stars: list of star dicts with 'ra' (hours) and 'dec' (deg)
    mst_edges: list of [i, j, weight]
    background_stars: list of star dicts with 'ra', 'dec', 'mag'

    Returns PNG bytes.
    """
    fig, ax = plt.subplots(figsize=(9, 7), dpi=160)
    fig.patch.set_facecolor("#0b1220")
    ax.set_facecolor("#0b1220")

    # Background noise stars, sized by brightness
    if background_stars:
        bg_x = [s["ra"] * 15.0 for s in background_stars]
        bg_y = [s["dec"] for s in background_stars]
        bg_size = [max(1.0, (7.0 - s["mag"]) * 2.2) for s in background_stars]
        ax.scatter(bg_x, bg_y, s=bg_size, c="#8fa5c0", alpha=0.55,
                   linewidths=0, zorder=1)

    # MST constellation lines
    if message_stars and mst_edges:
        xs = [s["ra"] * 15.0 for s in message_stars]
        ys = [s["dec"] for s in message_stars]
        for i, j, _w in mst_edges:
            ax.plot([xs[i], xs[j]], [ys[i], ys[j]],
                    color="#4fd8ff", linewidth=1.4, alpha=0.85, zorder=2)
        sizes = [max(30.0, (7.0 - s["mag"]) * 14) for s in message_stars]
        ax.scatter(xs, ys, s=sizes, c="#eaf6ff", edgecolors="#4fd8ff",
                   linewidths=1.2, zorder=3)

    ax.set_xlim(360, 0)  # RA increases to the left on sky maps
    ax.set_ylim(-90, 90)
    ax.set_xlabel("Right Ascension (deg)", color="#8fa5c0", fontsize=9)
    ax.set_ylabel("Declination (deg)", color="#8fa5c0", fontsize=9)
    ax.tick_params(colors="#8fa5c0", labelsize=8)
    for spine in ax.spines.values():
        spine.set_color("#2a3b52")
    ax.grid(True, color="#1c2b3f", linewidth=0.6)
    ax.set_title(title, color="#eaf6ff", fontsize=13, fontfamily="monospace")

    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", facecolor=fig.get_facecolor())
    plt.close(fig)
    buf.seek(0)
    return buf.getvalue()
