/* =====================================================================
   Stellar-Cipher — script.js
   Talks to the Flask API, draws the sky on a canvas, handles zoom/pan,
   tooltips and the live console log.
   ===================================================================== */

(() => {
  "use strict";

  const API_BASE = "/api";

  // ---------------------------------------------------------------- DOM
  const el = (id) => document.getElementById(id);

  const modeToggle      = el("modeToggle");
  const messageField    = el("messageField");
  const encodedField    = el("encodedField");
  const messageInput    = el("messageInput");
  const encodedInput    = el("encodedInput");
  const keyInput        = el("keyInput");
  const msgCount        = el("msgCount");
  const noiseSlider     = el("noiseSlider");
  const noiseValue      = el("noiseValue");
  const processBtn      = el("processBtn");
  const processBtnLabel = el("processBtnLabel");
  const pipelineSteps   = el("pipelineSteps");

  const encodedOutputField = el("encodedOutputField");
  const encodedOutput      = el("encodedOutput");
  const copyEncodedBtn     = el("copyEncodedBtn");
  const copyStatus         = el("copyStatus");

  const canvas       = el("skyCanvas");
  const ctx          = canvas.getContext("2d");
  const tooltip      = el("tooltip");
  const emptyState   = el("emptyState");
  const decodedBox   = el("decodedMessageBox");
  const decodedText  = el("decodedMessageText");

  const zoomInBtn    = el("zoomInBtn");
  const zoomOutBtn   = el("zoomOutBtn");
  const resetViewBtn = el("resetViewBtn");
  const exportBtn    = el("exportBtn");

  const metricEntropy = el("metricEntropy");
  const metricLength  = el("metricLength");
  const metricEdges   = el("metricEdges");
  const statusCatalog = el("statusCatalog");
  const statusApi     = el("statusApi");
  const consoleLog    = el("consoleLog");

  el("footerYear").textContent = new Date().getFullYear();

  // -------------------------------------------------------------- state
  let mode = "encode";
  let currentData = null;     // last successful API payload
  let view = { scale: 1, offsetX: 0, offsetY: 0 };
  let isDragging = false;
  let dragStart = { x: 0, y: 0 };
  let backgroundStars = [];   // shown while idle / before first request

  // ----------------------------------------------------------- console
  function log(message, level = "") {
    const line = document.createElement("div");
    line.className = "log-line" + (level ? ` log-${level}` : "");
    const time = new Date().toLocaleTimeString([], { hour12: false });
    line.textContent = `[${time}] ${message}`;
    consoleLog.appendChild(line);
    consoleLog.scrollTop = consoleLog.scrollHeight;
    while (consoleLog.children.length > 200) {
      consoleLog.removeChild(consoleLog.firstChild);
    }
  }

  // ------------------------------------------------------------- fetch
  async function api(path, options = {}) {
    const res = await fetch(API_BASE + path, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
    let body;
    try { body = await res.json(); }
    catch { throw new Error("Server returned an invalid response"); }
    if (!res.ok || body.success === false) {
      throw new Error(body.error || `Request failed (${res.status})`);
    }
    return body;
  }

  // -------------------------------------------------------- mode toggle
  modeToggle.addEventListener("click", (e) => {
    const btn = e.target.closest(".mode-btn");
    if (!btn) return;
    mode = btn.dataset.mode;
    [...modeToggle.children].forEach((b) => {
      const active = b === btn;
      b.classList.toggle("active", active);
      b.setAttribute("aria-selected", active);
    });
    messageField.classList.toggle("hidden", mode !== "encode");
    encodedField.classList.toggle("hidden", mode !== "decode");
    decodedBox.classList.add("hidden");
    encodedOutputField.classList.add("hidden");
    processBtnLabel.textContent = mode === "encode" ? "ENCRYPT MESSAGE" : "DECRYPT TRANSMISSION";
    log(`Transmission mode set to ${mode.toUpperCase()}`, "info");
  });

  messageInput.addEventListener("input", () => {
    msgCount.textContent = messageInput.value.length;
  });

  noiseSlider.addEventListener("input", () => {
    noiseValue.textContent = noiseSlider.value;
  });

  // ------------------------------------------------------------- pipeline
  function runPipeline(activeSteps) {
    const stepEls = [...pipelineSteps.children];
    stepEls.forEach((li) => li.classList.remove("active", "done"));
    let i = 0;
    const interval = setInterval(() => {
      if (i > 0) stepEls[i - 1].classList.replace("active", "done");
      if (i >= stepEls.length) { clearInterval(interval); return; }
      stepEls[i].classList.add("active");
      i++;
    }, 220);
    return () => {
      clearInterval(interval);
      stepEls.forEach((li) => li.classList.add("done"));
      stepEls.forEach((li) => li.classList.remove("active"));
    };
  }

  // -------------------------------------------------------- process btn
  processBtn.addEventListener("click", async () => {
    const key = keyInput.value;
    if (!key || key.length < 4) {
      log("Security key must be at least 4 characters", "error");
      return;
    }

    processBtn.disabled = true;
    decodedBox.classList.add("hidden");
    const finishPipeline = runPipeline();

    try {
      let result;
      const noiseCount = 350;
      const maxMag = parseFloat(noiseSlider.value);

      if (mode === "encode") {
        const message = messageInput.value.trim();
        if (!message) throw new Error("Enter a message to encrypt");
        log(`Encrypting message (${message.length} chars) with AES-128...`, "");
        result = await api("/encrypt", {
          method: "POST",
          body: JSON.stringify({ message, key, noiseCount, maxMag }),
        });
        encodedOutput.value = result.encoded;
        encodedOutputField.classList.remove("hidden");
        copyStatus.textContent = "\u00A0";
        copyEncodedBtn.classList.remove("copied");
        log(`Encoded transmission ready (${result.encoded.length} chars) — copy it to decode later`, "success");
      } else {
        const encoded = encodedInput.value.trim();
        if (!encoded) throw new Error("Paste an encoded transmission to decrypt");
        encodedOutputField.classList.add("hidden");
        log("Decrypting transmission with AES-128...", "");
        result = await api("/decrypt", {
          method: "POST",
          body: JSON.stringify({ encoded, key, noiseCount, maxMag }),
        });
        decodedText.textContent = result.message;
        decodedBox.classList.remove("hidden");
        log(`Decrypted message recovered (${result.message.length} chars)`, "success");
      }

      currentData = result;
      updateMetrics(result.metrics);
      resetView();
      draw();
      emptyState.classList.add("hidden");
      log(`Constellation rendered: ${result.stars.length} nodes, ${result.mstEdges.length} edges`, "success");
    } catch (err) {
      log(err.message, "error");
    } finally {
      finishPipeline();
      processBtn.disabled = false;
    }
  });

  function updateMetrics(m) {
    if (!m) return;
    metricEntropy.textContent = `${m.entropy} bits`;
    metricLength.textContent = m.stringLength;
    metricEdges.textContent = m.graphEdges;
  }

  // ----------------------------------------------------- canvas sizing
  function resizeCanvas() {
    const frame = canvas.parentElement;
    const dpr = window.devicePixelRatio || 1;
    const rect = frame.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    canvas.style.width = rect.width + "px";
    canvas.style.height = rect.height + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    draw();
  }
  window.addEventListener("resize", resizeCanvas);

  // ----------------------------------------------------- projection
  // RA in hours (0-24) -> x, Dec in degrees (-90..90) -> y, equirectangular
  function project(ra, dec, w, h) {
    const x = ((24 - ra) / 24) * w;
    const y = ((90 - dec) / 180) * h;
    return { x, y };
  }

  function toScreen(x, y) {
    return {
      x: x * view.scale + view.offsetX,
      y: y * view.scale + view.offsetY,
    };
  }

  // -------------------------------------------------------------- draw
  let hoverStar = null;

  function draw() {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    ctx.clearRect(0, 0, w, h);

    // grid
    ctx.strokeStyle = "rgba(47,216,255,0.06)";
    ctx.lineWidth = 1;
    for (let gx = 0; gx <= w; gx += w / 12) {
      const a = toScreen(gx, 0), b = toScreen(gx, h);
      ctx.beginPath(); ctx.moveTo(a.x, 0); ctx.lineTo(b.x, h); ctx.stroke();
    }
    for (let gy = 0; gy <= h; gy += h / 8) {
      const a = toScreen(0, gy), b = toScreen(w, gy);
      ctx.beginPath(); ctx.moveTo(0, a.y); ctx.lineTo(w, b.y); ctx.stroke();
    }

    const bg = currentData ? currentData.backgroundStars : backgroundStars;

    // background noise stars
    bg.forEach((s) => {
      const p = project(s.ra, s.dec, w, h);
      const sp = toScreen(p.x, p.y);
      const r = Math.max(0.5, (7 - s.mag) * 0.35);
      ctx.beginPath();
      ctx.fillStyle = "rgba(180,200,225,0.55)";
      ctx.arc(sp.x, sp.y, r, 0, Math.PI * 2);
      ctx.fill();
    });

    if (!currentData) return;

    const stars = currentData.stars;
    const points = stars.map((s) => {
      const p = project(s.ra, s.dec, w, h);
      return toScreen(p.x, p.y);
    });

    // MST edges
    ctx.strokeStyle = "rgba(79,216,255,0.85)";
    ctx.lineWidth = 1.4;
    ctx.shadowColor = "rgba(79,216,255,0.6)";
    ctx.shadowBlur = 6;
    currentData.mstEdges.forEach(([i, j]) => {
      ctx.beginPath();
      ctx.moveTo(points[i].x, points[i].y);
      ctx.lineTo(points[j].x, points[j].y);
      ctx.stroke();
    });
    ctx.shadowBlur = 0;

    // message stars
    stars.forEach((s, idx) => {
      const p = points[idx];
      const r = Math.max(3, (7 - s.mag) * 1.1);
      const isHover = hoverStar === idx;

      ctx.beginPath();
      ctx.fillStyle = isHover ? "#ffffff" : "#eaf6ff";
      ctx.shadowColor = "#4fd8ff";
      ctx.shadowBlur = isHover ? 18 : 10;
      ctx.arc(p.x, p.y, isHover ? r + 2 : r, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.beginPath();
      ctx.strokeStyle = "#4fd8ff";
      ctx.lineWidth = 1.2;
      ctx.arc(p.x, p.y, r + 3, 0, Math.PI * 2);
      ctx.stroke();
    });
  }

  // ------------------------------------------------------- pan / zoom
  function resetView() {
    view = { scale: 1, offsetX: 0, offsetY: 0 };
  }

  canvas.addEventListener("wheel", (e) => {
    e.preventDefault();
    const delta = e.deltaY < 0 ? 1.1 : 0.9;
    const newScale = Math.min(6, Math.max(0.5, view.scale * delta));
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    view.offsetX = mx - (mx - view.offsetX) * (newScale / view.scale);
    view.offsetY = my - (my - view.offsetY) * (newScale / view.scale);
    view.scale = newScale;
    draw();
  }, { passive: false });

  canvas.addEventListener("mousedown", (e) => {
    isDragging = true;
    dragStart = { x: e.clientX - view.offsetX, y: e.clientY - view.offsetY };
  });
  window.addEventListener("mouseup", () => { isDragging = false; });
  canvas.addEventListener("mousemove", (e) => {
    if (isDragging) {
      view.offsetX = e.clientX - dragStart.x;
      view.offsetY = e.clientY - dragStart.y;
      draw();
      return;
    }
    handleHover(e);
  });
  canvas.addEventListener("mouseleave", () => {
    hoverStar = null;
    tooltip.classList.add("hidden");
  });

  function handleHover(e) {
    if (!currentData) return;
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    const w = canvas.clientWidth, h = canvas.clientHeight;

    let found = null;
    currentData.stars.forEach((s, idx) => {
      const p = project(s.ra, s.dec, w, h);
      const sp = toScreen(p.x, p.y);
      const dist = Math.hypot(sp.x - mx, sp.y - my);
      if (dist < 10) found = { idx, sp, star: s };
    });

    if (found) {
      hoverStar = found.idx;
      tooltip.classList.remove("hidden");
      tooltip.style.left = found.sp.x + "px";
      tooltip.style.top = found.sp.y + "px";
      const s = found.star;
      tooltip.innerHTML =
        `<strong>${s.name || "Unnamed star"}</strong><br>` +
        `RA: ${s.ra.toFixed(2)}h, Dec: ${s.dec.toFixed(1)}°<br>` +
        `Mag: ${s.mag.toFixed(1)} · Byte: 0x${s.byteHex}`;
    } else {
      hoverStar = null;
      tooltip.classList.add("hidden");
    }
    draw();
  }

  // touch support (basic pan)
  let lastTouch = null;
  canvas.addEventListener("touchstart", (e) => {
    if (e.touches.length === 1) {
      lastTouch = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
  }, { passive: true });
  canvas.addEventListener("touchmove", (e) => {
    if (e.touches.length === 1 && lastTouch) {
      const t = e.touches[0];
      view.offsetX += t.clientX - lastTouch.x;
      view.offsetY += t.clientY - lastTouch.y;
      lastTouch = { x: t.clientX, y: t.clientY };
      draw();
    }
  }, { passive: true });
  canvas.addEventListener("touchend", () => { lastTouch = null; });

  zoomInBtn.addEventListener("click", () => { view.scale = Math.min(6, view.scale * 1.25); draw(); });
  zoomOutBtn.addEventListener("click", () => { view.scale = Math.max(0.5, view.scale / 1.25); draw(); });
  resetViewBtn.addEventListener("click", () => { resetView(); draw(); log("View reset", "info"); });

  // -------------------------------------------------------- copy output
  copyEncodedBtn.addEventListener("click", async () => {
    const text = encodedOutput.value;
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // clipboard API unavailable (e.g. non-HTTPS context) — fall back
      encodedOutput.select();
      document.execCommand("copy");
    }
    copyEncodedBtn.classList.add("copied");
    copyStatus.textContent = "Copied to clipboard";
    log("Encoded transmission copied to clipboard", "success");
    setTimeout(() => {
      copyEncodedBtn.classList.remove("copied");
      copyStatus.textContent = "\u00A0";
    }, 2000);
  });

  // ------------------------------------------------------------- export
  exportBtn.addEventListener("click", async () => {
    if (!currentData) { log("Nothing to export yet", "error"); return; }
    log("Rendering PNG export...", "");
    try {
      const res = await fetch(API_BASE + "/plot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          stars: currentData.stars,
          mstEdges: currentData.mstEdges,
          backgroundStars: currentData.backgroundStars,
          title: "STELLAR-CIPHER",
        }),
      });
      if (!res.ok) throw new Error("Export failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "stellar-cipher-constellation.png";
      a.click();
      URL.revokeObjectURL(url);
      log("PNG exported", "success");
    } catch (err) {
      log(err.message, "error");
    }
  });

  // --------------------------------------------------------- bootstrap
  async function bootstrap() {
    log("Booting Stellar-Cipher interface...", "info");
    try {
      const health = await api("/health");
      statusCatalog.textContent = `${health.catalogSize} STARS`;
      statusCatalog.className = "status-pill status-online";
      statusApi.textContent = "ONLINE";
      statusApi.className = "status-pill status-online";
      log(`Star catalog loaded: ${health.catalogSize} stars`, "success");

      const noise = await api(`/noise?count=280&maxMag=4.5`);
      backgroundStars = noise.backgroundStars;
      draw();
    } catch (err) {
      statusCatalog.textContent = "OFFLINE";
      statusCatalog.className = "status-pill status-offline";
      statusApi.textContent = "OFFLINE";
      statusApi.className = "status-pill status-offline";
      log(`Backend unreachable: ${err.message}`, "error");
    }
  }

  resizeCanvas();
  bootstrap();
})();
